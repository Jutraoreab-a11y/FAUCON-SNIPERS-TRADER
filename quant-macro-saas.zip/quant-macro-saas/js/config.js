// ============================================================
// CONFIGURATION — à remplir avec tes propres clés Supabase
// Supabase Dashboard > Project Settings > API
// ============================================================
window.SUPABASE_URL = "https://TON-PROJET.supabase.co";
window.SUPABASE_ANON_KEY = "TA_CLE_ANON_PUBLIQUE";
